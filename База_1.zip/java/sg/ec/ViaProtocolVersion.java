package sg.ec;

import com.viaversion.viafabricplus.ViaFabricPlus;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import lombok.Generated;
import sg.client.DimasikClient;

public final class ViaProtocolVersion {
   private static final String сОэ = "This is a utility class and cannot be instantiated";

   @Generated
   private ViaProtocolVersion() {
      throw new UnsupportedOperationException(сОэ);
   }

   public static ProtocolVersion Г() {
      return DimasikClient.getInstance().getServices().getViaIntegration().Як() ? ViaFabricPlus.getImpl().getTargetVersion() : null;
   }
}
