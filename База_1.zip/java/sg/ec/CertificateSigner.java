package sg.ec;

import java.io.InputStream;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import lombok.Generated;

public final class CertificateSigner {
   public static byte[] 西(byte[] var0) {
      try {
         PrivateKey var1 = з();
         if (var1 == null) {
            return null;
         }

         Signature var2 = Signature.getInstance("Ed25519");
         var2.initSign(var1);
         var2.update(var0);
         return var2.sign();
      } catch (Exception var3) {
         System.out.println(var3.getMessage());
         return null;
      }
   }

   private static PrivateKey з() {
      try (InputStream var0 = CertificateSigner.class.getResourceAsStream("/certificate/private.key")) {
         if (var0 == null) {
            return null;
         }

         byte[] var1 = var0.readAllBytes();
         PKCS8EncodedKeySpec var2 = new PKCS8EncodedKeySpec(var1);
         KeyFactory var3 = KeyFactory.getInstance("Ed25519");
         return var3.generatePrivate(var2);
      } catch (Exception var7) {
         System.out.println(var7.getMessage());
         return null;
      }
   }

   @Generated
   private CertificateSigner() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
