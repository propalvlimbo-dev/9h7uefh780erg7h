package sg.ec;

import java.io.IOException;
import java.util.LinkedHashSet;
import settings.render.AnyDeskRelayProtocol;

public final class AnyDeskPublicAddressDecoder {
   private static final long сЧ诶 = 12L;
   private static final String сЧ1 = ", ";

   private static boolean method_7(int var0, int var1, int var2) {
      return var0 != 0
         && var0 != 10
         && var0 != 127
         && var0 < 224
         && (var0 != 100 || var1 < 64 || var1 > 127)
         && (var0 != 169 || var1 != 254)
         && (var0 != 172 || var1 < 16 || var1 > 31)
         && (var0 != 192 || var1 != 168 && (var1 != 0 || var2 != 0 && var2 != 2) && (var1 != 88 || var2 != 99))
         && (var0 != 198 || var1 != 18 && var1 != 19 && (var1 != 51 || var2 != 100))
         && (var0 != 203 || var1 != 0 || var2 != 113);
   }

   private AnyDeskPublicAddressDecoder() {
   }

   public static String П(byte[] var0) throws IOException {
      AnyDeskRelayProtocol.я_804d2d52(var0);
      AnyDeskRelayProtocol.PacketReader var1 = new AnyDeskRelayProtocol.PacketReader(var0);
      var1.б(сЧ诶);
      long var2 = var1.з();
      LinkedHashSet var4 = new LinkedHashSet();

      for (long var5 = 0L; var5 < var2; var5++) {
         int var7 = var1.бж();
         int var8 = var1.бж();
         int var9 = var1.бж();
         int var10 = var1.бж();
         int var11 = var1.бж();
         int var12 = var1.бб();
         if ((var7 == 1 || var7 == 2) && var12 != 0 && method_7(var8, var9, var10)) {
            var4.add(var8 + "." + var9 + "." + var10 + "." + var11);
         }
      }

      return var4.isEmpty() ? null : String.join(сЧ1, var4);
   }
}
