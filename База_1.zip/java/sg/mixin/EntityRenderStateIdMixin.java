package sg.mixin;

import sg.mixinbridge.EntityRenderStateIdAccess;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(EntityRenderState.class)
public abstract class EntityRenderStateIdMixin implements EntityRenderStateIdAccess {
   @Unique
   private int dimasik$entityId;
   private static final int ВьЦ = Integer.MIN_VALUE;

   public EntityRenderStateIdMixin() {
      this.dimasik$entityId = ВьЦ;
   }

   @Override
   public int dimasik$getEntityId() {
      return this.dimasik$entityId;
   }

   @Override
   public void dimasik$setEntityId(int var1) {
      this.dimasik$entityId = var1;
   }
}
