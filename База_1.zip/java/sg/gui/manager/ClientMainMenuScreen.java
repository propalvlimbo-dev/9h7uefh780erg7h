package sg.gui.manager;

/** Existing callers now open the fully ported NowDLC main menu. */
public final class ClientMainMenuScreen extends sg.gui.manager.now.MainMenuScreen {
   public void resumeFromOverlay() { }
}
