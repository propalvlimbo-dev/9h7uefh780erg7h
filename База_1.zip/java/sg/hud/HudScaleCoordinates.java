package sg.hud;

import lombok.Generated;
import sg.client.DimasikClient;

public final class HudScaleCoordinates {
   private static final String UTILITY_CLASS_MESSAGE = "This is a utility class and cannot be instantiated";

   public static float unscaleY(float y, float originY) {
      return originY + (y - originY) / getHudScale();
   }

   public static float unscaleX(float x, float originX) {
      return originX + (x - originX) / getHudScale();
   }

   public static float getHudScale() {
      try {
         return DimasikClient.getInstance() != null
               && DimasikClient.getInstance().getServices() != null
               && DimasikClient.getInstance().getServices().getModules() != null
               && DimasikClient.getInstance().getServices().getModules().getHud() != null
            ? DimasikClient.getInstance().getServices().getModules().getHud().зй()
            : 1.0F;
      } catch (Throwable ignored) {
         return 1.0F;
      }
   }

   @Generated
   private HudScaleCoordinates() {
      throw new UnsupportedOperationException(UTILITY_CLASS_MESSAGE);
   }
}
