package settings.render;

import com.google.gson.annotations.SerializedName;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public final class AnyDeskRelayProtocol {
   static final int ЪЪ = 1048576;
   public static final int[] н = new int[]{1, 2, 3, 4, 7, 9, 10, 11, 12, 13, 14, 15};
   private static final int са7 = 65535;
   private static final int саР = 65535;
   private static final String са3 = "Invalid relay frame";
   private static final String сар = "No supported relay version";
   private static final long са6 = 6L;
   private static final long са_ = 5L;
   private static final String саШ = "Unsupported ACK revision";
   private static final String саы = "Unknown ACK flags";
   private static final long сай = 6L;
   private static final long саЖ = 16L;
   private static final long сам = 6L;
   private static final long саК = 16L;
   private static final long саI = 8L;
   private static final String саТ = "Relay did not assign an ID";
   private static final String саО = "Unsupported relay terminal revision";
   private static final String саФ = ".net.anydesk.com";
   private static final String саЙ = "Unsupported incoming request revision";
   private static final long сак = 7L;
   private static final long саг = 8L;
   private static final long са0 = 8L;
   private static final String сах = "Expected session request";
   private static final String саУ = "Invalid excluded version count";
   private static final long саЗ = 2L;
   private static final long саЕ = 2L;
   private static final long саП = 2L;
   private static final long са西 = 10L;
   private static final long сад = 8L;
   private static final long саБ = 6L;
   private static final String саС = "No supported session version";
   private static final String саз = "Python transport test";
   private static final String сац = "No screen or input access";
   private static final long сая = 2L;
   private static final long сЮс = 6L;
   private static final long сЮВ = 5L;
   private static final int сЮЯ = 60000;
   private static final String сЮХ = "Invalid outgoing stream message";

   public static byte[] я(int var0, byte[] var1) {
      if (var0 >= 0 && var0 <= 10 && var1.length != 0 && var1.length <= сЮЯ) {
         byte[] var2 = new AnyDeskRelayProtocol.PacketWriter().щ(var1.length).щ(var1).Р();
         byte[] var3 = new AnyDeskRelayProtocol.PacketWriter().щ(var0, 1).щ(var2.length).щ(var2).Р();
         return new AnyDeskRelayProtocol.PacketWriter().щ(var3.length).щ(var3).Р();
      } else {
         throw new IllegalArgumentException(сЮХ);
      }
   }

   public static int я_a83dd0cc(byte[] var0) throws IOException {
      AnyDeskRelayProtocol.PacketReader var1 = new AnyDeskRelayProtocol.PacketReader(var0);
      int var2 = var1.бб();
      int var3 = var1.бб();
      int var4 = var1.бб();
      HashSet var5 = new HashSet();

      for (int var6 = 0; var6 < var4; var6++) {
         var5.add(var1.бб());
      }

      var1.лЭ();

      for (int var9 : new int[]{3, 2}) {
         if (var2 <= var9 && var9 <= var3 && !var5.contains(var9)) {
            return var9;
         }
      }

      throw new IOException(сар);
   }

   public static String l(byte[] var0) throws IOException {
      AnyDeskRelayProtocol.PacketReader var1 = new AnyDeskRelayProtocol.PacketReader(var0);
      if (var1.бж() != 1) {
         throw new IOException(саО);
      }

      int var2 = var1.бж();
      var1.з();
      String var3 = null;
      int var4 = var1.бж();

      for (int var5 = 0; var5 < var4; var5++) {
         var1.б(var1.бж());
         int var6 = var1.бж();

         for (int var7 = 0; var7 < var6; var7++) {
            var1.з();
            String var8 = new String(var1.б(var1.бж()), StandardCharsets.US_ASCII);
            int var9 = var1.бж();

            for (int var10 = 0; var10 < var9; var10++) {
               int var11 = var1.бб();
               if (var3 == null && var11 == 443 && var8.endsWith(саФ)) {
                  var3 = var8;
               }
            }
         }
      }

      var1.лЭ();
      if (var3 == null) {
         throw new IOException("Relay closed registration, reason " + var2);
      } else {
         return var3;
      }
   }

   public static long я_6da43b94(byte[] var0) throws IOException {
      AnyDeskRelayProtocol.PacketReader var1 = new AnyDeskRelayProtocol.PacketReader(var0);
      if (var1.бж() != 0) {
         throw new IOException(саШ);
      }

      int var2 = var1.бб();
      if ((var2 & -256) != 0) {
         throw new IOException(саы);
      }

      long var3 = 0L;
      if ((var2 & 1) != 0) {
         var3 = var1.з();
         var1.лЫ();
      }

      if ((var2 & 2) != 0) {
         var1.б(сай);
      }

      if ((var2 & 4) != 0) {
         var1.бж();
         var1.лЫ();
         var1.б(саЖ);
      }

      if ((var2 & 8) != 0) {
         var1.б(сам);
      }

      if ((var2 & 16) != 0) {
         var1.б(var1.бж());
      }

      if ((var2 & 32) != 0) {
         var1.б(var1.з() * саК);
      }

      if ((var2 & 64) != 0) {
         var1.б(var1.бж() * саI);
      }

      if ((var2 & 128) != 0) {
         var1.лЫ();
      }

      var1.лЭ();
      if (var3 == 0L) {
         throw new IOException(саТ);
      } else {
         return var3;
      }
   }

   public static byte[] я(int var0, long var1) {
      return new AnyDeskRelayProtocol.PacketWriter()
         .щ(1L, 1)
         .щ(var0, 4)
         .щ(var1, 4)
         .Р(саз.getBytes(StandardCharsets.UTF_8))
         .Р(сац.getBytes(StandardCharsets.UTF_8))
         .щ(0L, 1)
         .щ(0L, 8)
         .щ(0L, 2)
         .щ(сая, 4)
         .щ(сЮс, 2)
         .щ(0L, 2)
         .щ(сЮВ, 2)
         .Р();
   }

   public static byte[] я(int var0) {
      return new AnyDeskRelayProtocol.PacketWriter().щ(0L, 1).щ(var0, 2).щ(са6, 2).щ(0L, 2).щ(са_, 2).щ(0L, 2).щ(1L, 2).Р();
   }

   public static int method_2(byte[] var0) throws IOException {
      AnyDeskRelayProtocol.PacketReader var1 = new AnyDeskRelayProtocol.PacketReader(var0);
      if (var1.бж() != 0) {
         throw new IOException(сах);
      }

      long var2 = var1.з();
      var1.з();
      var1.лЫ();
      var1.лЫ();
      if (var1.бж() != 0) {
         var1.лЫ();
      }

      long var4 = 1L;
      HashSet var6 = new HashSet();
      if (var1.жк() > 0) {
         var4 = var1.з();
         long var7 = var1.з();
         if (var7 > var1.жк() / 4) {
            throw new IOException(саУ);
         }

         for (long var9 = 0L; var9 < var7; var9++) {
            var6.add(var1.з());
         }

         if (var2 <= саЗ && var4 >= саЕ && !var6.contains(саП)) {
            var1.бж();
         }

         if (var1.жк() > 0) {
            var1.б(са西);
         }

         if (var1.жк() > 0) {
            var1.лЫ();
            var1.б(сад);
         }

         long var12 = var1.жк() > 0 ? var1.з() : 0L;
         if ((var12 & 1L) != 0L) {
            var1.б(саБ);
         }
      }

      for (int var11 = 4; var11 >= 1; var11--) {
         if (var2 <= var11 && var11 <= var4 && !var6.contains((long)var11)) {
            return var11;
         }
      }

      throw new IOException(саС);
   }

   AnyDeskRelayProtocol() {
   }

   public static byte[] я(int var0, int var1, byte[] var2) {
      if (var0 >= 0 && var0 < са7 && var2.length + 3 < саР) {
         return new AnyDeskRelayProtocol.PacketWriter().щ(var2.length + 3, 2).щ(var0, 2).щ(var1, 1).щ(var2).Р();
      } else {
         throw new IllegalArgumentException(са3);
      }
   }

   public static byte[] я(long var0, int var2) {
      return new AnyDeskRelayProtocol.PacketWriter().щ(0L, 1).щ(var0, 4).щ(1L, 1).щ(var2, 2).щ(0L, 4).Р();
   }

   public static AnyDeskRelayProtocol.IncomingRequest я_804d2d52(byte[] var0) throws IOException {
      AnyDeskRelayProtocol.PacketReader var1 = new AnyDeskRelayProtocol.PacketReader(var0);
      if (var1.бж() != 0) {
         throw new IOException(саЙ);
      }

      long var2 = var1.з();
      int var4 = var1.бж();
      long var5 = var1.з();
      var1.бб();
      var1.б(var1.з() * сак);
      if ((var4 & 8) != 0) {
         var1.б(саг);
      }

      if ((var4 & 16) != 0) {
         var1.б(са0);
      }

      var1.лЭ();
      return new AnyDeskRelayProtocol.IncomingRequest(var2, var5);
   }

   public static final class PacketReader {
      private final byte[] Х;
      @SerializedName("4Г")
      private int field_4Г;
      private static final String Чф = "Truncated packet";
      private static final String Чи = "Truncated packet";
      private static final String Ч9 = "Varint32 overflow";
      private static final String Чо = "Unterminated varint";
      private static final String ЧO = "Unexpected trailing data";

      public byte[] б(long var1) throws IOException {
         if (var1 >= 0L && var1 <= this.жк()) {
            byte[] var3 = Arrays.copyOfRange(this.Х, this.field_4Г, this.field_4Г + (int)var1);
            this.field_4Г += (int)var1;
            return var3;
         } else {
            throw new IOException(Чф);
         }
      }

      public PacketReader(byte[] var1) {
         this.Х = var1;
      }

      public long з() throws IOException {
         return (long)this.бб() << 16 | this.бб();
      }

      public int бж() throws IOException {
         if (this.жк() == 0) {
            throw new IOException(Чи);
         } else {
            return this.Х[this.field_4Г++] & 0xFF;
         }
      }

      public int бб() throws IOException {
         return this.бж() << 8 | this.бж();
      }

      public void лЭ() throws IOException {
         if (this.жк() != 0) {
            throw new IOException(ЧO);
         }
      }

      int жк() {
         return this.Х.length - this.field_4Г;
      }

      long п() throws IOException {
         long var1 = 0L;

         for (int var3 = 0; var3 < 5; var3++) {
            int var4 = this.бж();
            if (var3 == 4 && var4 > 15) {
               throw new IOException(Ч9);
            }

            var1 |= (long)(var4 & 127) << 7 * var3;
            if (var4 < 128) {
               return var1;
            }
         }

         throw new IOException(Чо);
      }

      void лЫ() throws IOException {
         this.б(this.з());
      }
   }

   public static final class StreamDecoder {
      private final AnyDeskRelayProtocol.RecordReassembler В = new AnyDeskRelayProtocol.RecordReassembler();
      private final Map<Integer, AnyDeskRelayProtocol.RecordReassembler> сЕ = new HashMap<>();
      private static final String ВЙз = "Unsupported stream lane";

      public List<AnyDeskRelayProtocol.StreamMessage> С(byte[] var1) throws IOException {
         ArrayList var2 = new ArrayList();

         for (byte[] var4 : this.В.э(var1)) {
            AnyDeskRelayProtocol.PacketReader var5 = new AnyDeskRelayProtocol.PacketReader(var4);

            while (var5.жк() > 0) {
               int var6 = var5.бж();
               if (var6 > 10) {
                  throw new IOException(ВЙз);
               }

               byte[] var7 = var5.б(var5.п());

               for (byte[] var9 : this.сЕ.computeIfAbsent(var6, var0 -> new AnyDeskRelayProtocol.RecordReassembler()).э(var7)) {
                  var2.add(new AnyDeskRelayProtocol.StreamMessage(var6, var9));
               }
            }
         }

         return var2;
      }
   }

   static final class RecordReassembler {
      private byte[] В = new byte[0];
      private static final long Ян5 = 1048576L;
      private static final String Янв = "Stream buffer limit";
      private static final String Янъ = "Varint32 overflow";
      private static final long ЯнМ = 1048576L;
      private static final String ЯнН = "Invalid stream record length";

      List<byte[]> э(byte[] var1) throws IOException {
         if ((long)this.В.length + var1.length > Ян5) {
            throw new IOException(Янв);
         }

         byte[] var2 = Arrays.copyOf(this.В, this.В.length + var1.length);
         System.arraycopy(var1, 0, var2, this.В.length, var1.length);
         ArrayList var3 = new ArrayList();
         int var4 = 0;

         label50:
         while (var4 < var2.length) {
            int var5 = var4;
            long var6 = 0L;
            boolean var8 = false;
            int var9 = 0;

            while (true) {
               if (var9 < 5 && var5 < var2.length) {
                  int var10 = var2[var5++] & 255;
                  if (var9 == 4 && var10 > 15) {
                     throw new IOException(Янъ);
                  }

                  var6 |= (long)(var10 & 127) << var9 * 7;
                  if (var10 >= 128) {
                     var9++;
                     continue;
                  }

                  var8 = true;
               }

               if (var8) {
                  if (var6 < 1L || var6 > ЯнМ) {
                     throw new IOException(ЯнН);
                  }

                  if (var6 <= var2.length - var5) {
                     var3.add(Arrays.copyOfRange(var2, var5, var5 + (int)var6));
                     var4 = var5 + (int)var6;
                     break;
                  }
               }
               break label50;
            }
         }

         this.В = Arrays.copyOfRange(var2, var4, var2.length);
         return var3;
      }
   }

   public record RelayFrame(int channel, int type, byte[] body) {
   }

   public record StreamMessage(int lane, byte[] body) {
   }

   public record IncomingRequest(long token, long peerId) {
   }

   public static final class PacketWriter {
      private final ByteArrayOutputStream В = new ByteArrayOutputStream();

      AnyDeskRelayProtocol.PacketWriter щ(byte[] var1) {
         this.В.writeBytes(var1);
         return this;
      }

      AnyDeskRelayProtocol.PacketWriter Р(byte[] var1) {
         return this.щ(var1.length, 4).щ(var1);
      }

      public byte[] Р() {
         return this.В.toByteArray();
      }

      public AnyDeskRelayProtocol.PacketWriter щ(long var1, int var3) {
         for (int var4 = var3 - 1; var4 >= 0; var4--) {
            this.В.write((int)(var1 >>> 8 * var4));
         }

         return this;
      }

      AnyDeskRelayProtocol.PacketWriter щ(int var1) {
         while (var1 >= 128) {
            this.В.write(var1 & 127 | 128);
            var1 >>>= 7;
         }

         this.В.write(var1);
         return this;
      }
   }
}
