package dev.minee.hud;

public record Size(float width, float height) {
}
