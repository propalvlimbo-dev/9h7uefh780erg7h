package dev.minee.mixin;

import dev.minee.module.impl.world.ItemPhysicsModule;
import net.minecraft.client.renderer.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;


@Mixin(ItemEntityRenderState.class)
public abstract class ItemEntityRenderStateMixin implements ItemPhysicsModule.State {
   @Unique
   private boolean minee$onGround;
   @Unique
   private int minee$id;
   @Unique
   private boolean minee$block;

   @Override
   public void minee$physics(boolean onGround, int id, boolean block) {
      this.minee$onGround = onGround;
      this.minee$id = id;
      this.minee$block = block;
   }

   @Override
   public boolean minee$onGround() {
      return this.minee$onGround;
   }

   @Override
   public int minee$id() {
      return this.minee$id;
   }

   @Override
   public boolean minee$block() {
      return this.minee$block;
   }
}
