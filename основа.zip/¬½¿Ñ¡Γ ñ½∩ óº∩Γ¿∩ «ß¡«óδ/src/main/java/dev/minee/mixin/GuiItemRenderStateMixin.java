package dev.minee.mixin;

import dev.minee.render.gpu.ItemAlpha;
import net.minecraft.client.gui.render.state.GuiItemRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(GuiItemRenderState.class)
public abstract class GuiItemRenderStateMixin implements ItemAlpha.Holder {
   @Unique
   private float minee$alpha = 1.0F;

   @Inject(method = "<init>", at = @At("TAIL"))
   private void minee$rememberAlpha(CallbackInfo ci) {
      this.minee$alpha = ItemAlpha.current;
   }

   @Override
   public float minee$alpha() {
      return this.minee$alpha;
   }
}
