package dev.minee.mixin;

import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;


@Mixin(ProgressScreen.class)
public interface ProgressScreenAccessor {
   @Accessor("header")
   Component minee$header();

   @Accessor("stage")
   Component minee$stage();

   @Accessor("progress")
   int minee$progress();
}
