package dev.minee.mixin;

import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;


@Mixin(MouseHandler.class)
public interface MouseHandlerAccessor {
   @Accessor("xpos")
   void minee$setX(double var1);

   @Accessor("ypos")
   void minee$setY(double var1);
}
