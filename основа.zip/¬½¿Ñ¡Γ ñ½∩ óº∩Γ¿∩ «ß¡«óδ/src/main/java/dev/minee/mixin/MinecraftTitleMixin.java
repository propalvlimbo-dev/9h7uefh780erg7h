package dev.minee.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.minee.MineeClient;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;


@Mixin(Minecraft.class)
public abstract class MinecraftTitleMixin {
   @ModifyReturnValue(method = "createTitle", at = @At("RETURN"))
   private String minee$testTitle(String title) {
      return MineeClient.uiTest() == null ? title : title + " — АВТОТЕСТ Mykvador, не трогать";
   }
}
