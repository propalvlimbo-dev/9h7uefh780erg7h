package dev.minee.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.minee.render.gpu.Blend;
import dev.minee.render.gpu.MineeShader;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.LayeringTransform;
import net.minecraft.client.renderer.rendertype.OutputTarget;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.Identifier;


public final class MineeRenderTypes {
   private static final Map<Identifier, RenderType> GLOW_SPRITES = new HashMap<>();
   private static final Map<Identifier, RenderType> GLOW_SPRITES_THROUGH = new HashMap<>();
   private static final Map<Identifier, RenderType> SOFT_SPRITES = new HashMap<>();
   private static final Map<Identifier, RenderType> LIT = new HashMap<>();
   private static final OutputTarget GLOW_TARGET = new OutputTarget("minee_glow_target", GlowEngine::glowTarget);
   private static final OutputTarget HALO_TARGET = new OutputTarget("minee_halo_target", GlowEngine::haloTarget);
   private static final RenderPipeline GLOW_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelines.MATRICES_FOG_SNIPPET})
      .withLocation(id("pipeline/glow"))
      .withVertexShader("core/rendertype_lightning")
      .withFragmentShader("core/rendertype_lightning")
      .withBlend(BlendFunction.LIGHTNING)
      .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
      .withDepthWrite(false)
      .withCull(false)
      .build();
   private static final RenderPipeline GLOW_THROUGH_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelines.MATRICES_FOG_SNIPPET})
      .withLocation(id("pipeline/glow_through"))
      .withVertexShader("core/rendertype_lightning")
      .withFragmentShader("core/rendertype_lightning")
      .withBlend(BlendFunction.LIGHTNING)
      .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
      .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
      .withDepthWrite(false)
      .withCull(false)
      .build();
   private static final RenderPipeline FACES_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelines.MATRICES_PROJECTION_SNIPPET})
      .withLocation(id("pipeline/faces"))
      .withVertexShader("core/position_color")
      .withFragmentShader("core/position_color")
      .withBlend(BlendFunction.TRANSLUCENT)
      .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
      .withDepthWrite(false)
      .withCull(false)
      .build();
   public static final RenderType GLOW = RenderType.create(
      "minee_glow", RenderSetup.builder(GLOW_PIPELINE).setOutputTarget(GLOW_TARGET).sortOnUpload().bufferSize(8192).createRenderSetup()
   );
   public static final RenderType FACES = RenderType.create(
      "minee_faces", RenderSetup.builder(FACES_PIPELINE).setLayeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING).sortOnUpload().createRenderSetup()
   );
   public static final RenderType ITEM_SILHOUETTE = silhouette("minee_item_silhouette", TextureAtlas.LOCATION_BLOCKS);
   public static final RenderType ITEM_SILHOUETTE_ITEMS = silhouette("minee_item_silhouette_items", TextureAtlas.LOCATION_ITEMS);
   public static final RenderType GLOW_THROUGH = RenderType.create(
      "minee_glow_through", RenderSetup.builder(GLOW_THROUGH_PIPELINE).setOutputTarget(GLOW_TARGET).sortOnUpload().bufferSize(2048).createRenderSetup()
   );
   private static final RenderPipeline ADDITIVE_ENTITY_PIPELINE = RenderPipeline.builder(new Snippet[]{RenderPipelines.MATRICES_FOG_SNIPPET})
      .withLocation(id("pipeline/additive_entity"))
      .withVertexShader("core/entity")
      .withFragmentShader("core/entity")
      .withShaderDefine("EMISSIVE")
      .withShaderDefine("NO_OVERLAY")
      .withShaderDefine("NO_CARDINAL_LIGHTING")
      .withSampler("Sampler0")
      .withBlend(BlendFunction.ADDITIVE)
      .withDepthWrite(false)
      .withVertexFormat(DefaultVertexFormat.NEW_ENTITY, VertexFormat.Mode.QUADS)
      .build();
   private static final Map<Identifier, RenderType> ADDITIVE_ENTITY = new HashMap<>();

   private MineeRenderTypes() {
   }

   private static Identifier id(String path) {
      return Identifier.fromNamespaceAndPath("minee", path);
   }

   private static RenderType silhouette(String name, Identifier atlas) {
      return RenderType.create(
         name,
         RenderSetup.builder(Shaders.silhouette().pipeline(Blend.REPLACE, MineeShader.Depth.TEST))
            .withTexture("Sampler0", atlas)
            .setOutputTarget(HALO_TARGET)
            .bufferSize(4096)
            .createRenderSetup()
      );
   }

   public static RenderType glowSpriteThrough(Identifier texture) {
      return GLOW_SPRITES_THROUGH.computeIfAbsent(
         texture,
         id -> RenderType.create(
            "minee_glow_sprite_through",
            RenderSetup.builder(Shaders.softSprite().pipeline(Blend.LIGHTNING, MineeShader.Depth.NONE))
               .withTexture("Sampler0", id, MineeRenderTypes::smooth)
               .setOutputTarget(GLOW_TARGET)
               .sortOnUpload()
               .bufferSize(1024)
               .createRenderSetup()
         )
      );
   }

   public static RenderType glowSprite(Identifier texture) {
      return GLOW_SPRITES.computeIfAbsent(
         texture,
         id -> RenderType.create(
            "minee_glow_sprite",
            RenderSetup.builder(Shaders.softSprite().pipeline(Blend.LIGHTNING, MineeShader.Depth.TEST))
               .withTexture("Sampler0", id, MineeRenderTypes::smooth)
               .setOutputTarget(GLOW_TARGET)
               .sortOnUpload()
               .bufferSize(4096)
               .createRenderSetup()
         )
      );
   }

   public static RenderType softSprite(Identifier texture) {
      return SOFT_SPRITES.computeIfAbsent(
         texture,
         id -> RenderType.create(
            "minee_soft_sprite",
            RenderSetup.builder(Shaders.softSprite().pipeline(Blend.NORMAL, MineeShader.Depth.TEST))
               .withTexture("Sampler0", id, MineeRenderTypes::smooth)
               .setOutputTarget(OutputTarget.WEATHER_TARGET)
               .sortOnUpload()
               .bufferSize(4096)
               .createRenderSetup()
         )
      );
   }

   public static RenderType lit(Identifier texture) {
      return LIT.computeIfAbsent(
         texture,
         id -> RenderType.create(
            "minee_lit",
            RenderSetup.builder(RenderPipelines.ENTITY_TRANSLUCENT)
               .withTexture("Sampler0", id, MineeRenderTypes::smooth)
               .useLightmap()
               .useOverlay()
               .affectsCrumbling()
               .sortOnUpload()
               .bufferSize(4096)
               .setOutline(RenderSetup.OutlineProperty.AFFECTS_OUTLINE)
               .createRenderSetup()
         )
      );
   }

   public static RenderType lines() {
      return RenderTypes.lines();
   }

   public static RenderType additiveEntity(Identifier texture) {
      return ADDITIVE_ENTITY.computeIfAbsent(
         texture,
         id -> RenderType.create(
            "minee_additive_entity", RenderSetup.builder(ADDITIVE_ENTITY_PIPELINE).withTexture("Sampler0", id).sortOnUpload().createRenderSetup()
         )
      );
   }

   private static GpuSampler smooth() {
      return RenderSystem.getSamplerCache().getRepeat(FilterMode.LINEAR);
   }
}
