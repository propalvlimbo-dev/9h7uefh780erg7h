package dev.minee.render;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.minee.render.gpu.MineeShader;


public final class Shaders {
   private static final VertexFormat.Mode QUADS = VertexFormat.Mode.QUADS;
   private static final MineeShader SURFACE = MineeShader.create("surface", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader LIQUID_GLASS = MineeShader.create("liquid_glass", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader TEXT = MineeShader.create("sdf_text", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader KAWASE_DOWN = MineeShader.create("kawase_down", DefaultVertexFormat.POSITION, QUADS);
   private static final MineeShader KAWASE_UP = MineeShader.create("kawase_up", DefaultVertexFormat.POSITION, QUADS);
   private static final MineeShader ROUNDED_IMAGE = MineeShader.create("rounded_image", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader CHARACTER = MineeShader.create("character", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader POST_GRADE = MineeShader.create("post_grade", DefaultVertexFormat.POSITION, QUADS);
   private static final MineeShader SOFT_SPRITE = MineeShader.create("soft_sprite", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader GLOW_COMPOSITE = MineeShader.create("glow_composite", DefaultVertexFormat.POSITION, QUADS);
   private static final MineeShader SILHOUETTE = MineeShader.create("silhouette", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader BLACK_HOLE = MineeShader.create("black_hole", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);
   private static final MineeShader NEBULA = MineeShader.create("nebula", DefaultVertexFormat.POSITION_TEX_COLOR, QUADS);

   private Shaders() {
   }

   public static void register() {
   }

   public static MineeShader softSprite() {
      return SOFT_SPRITE;
   }

   public static MineeShader silhouette() {
      return SILHOUETTE;
   }

   public static MineeShader glowComposite() {
      return GLOW_COMPOSITE;
   }

   public static MineeShader surface() {
      return SURFACE;
   }

   public static MineeShader liquidGlass() {
      return LIQUID_GLASS;
   }

   public static MineeShader text() {
      return TEXT;
   }

   public static MineeShader kawaseDown() {
      return KAWASE_DOWN;
   }

   public static MineeShader character() {
      return CHARACTER;
   }

   public static MineeShader roundedImage() {
      return ROUNDED_IMAGE;
   }

   public static MineeShader postGrade() {
      return POST_GRADE;
   }

   public static MineeShader kawaseUp() {
      return KAWASE_UP;
   }

   public static MineeShader blackHole() {
      return BLACK_HOLE;
   }

   public static MineeShader nebula() {
      return NEBULA;
   }
}
