package dev.minee.render.gpu;

import dev.minee.MineeClient;
import java.util.ArrayList;
import java.util.List;


public final class GpuFrame {
   private static final List<Runnable> listeners = new ArrayList<>();
   private static long frame;

   private GpuFrame() {
   }

   public static long frame() {
      return frame;
   }

   public static void onEnd(Runnable action) {
      listeners.add(action);
   }

   public static void end() {
      frame++;

      try {
         MineeShader.endFrame();
         GuiDraw.endFrame();

         for (Runnable listener : listeners) {
            listener.run();
         }
      } catch (RuntimeException e) {
         MineeClient.LOGGER.error("[Mykvador] frame end failed", e);
      }
   }
}
