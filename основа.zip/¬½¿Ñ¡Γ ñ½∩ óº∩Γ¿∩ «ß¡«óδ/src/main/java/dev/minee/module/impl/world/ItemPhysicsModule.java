package dev.minee.module.impl.world;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.minee.module.Category;
import dev.minee.module.Module;
import dev.minee.setting.NumberSetting;


public final class ItemPhysicsModule extends Module {
   private final NumberSetting spin = this.add(new NumberSetting("spin", 100.0, 0.0, 200.0, 10.0, "minee.unit.percent"));

   public ItemPhysicsModule() {
      super("item_physics", Category.WORLD, false);
   }

   @Override
   public int icon() {
      return 58090;
   }

   public float lift(ItemPhysicsModule.State item, float rest) {
      return item.minee$onGround() && !item.minee$block() ? 0.02F : rest;
   }

   public void rotate(PoseStack pose, ItemPhysicsModule.State item, float ageInTicks) {
      boolean block = item.minee$block();
      float yaw = item.minee$id() * 37 % 360;
      if (item.minee$onGround()) {
         pose.mulPose(Axis.YP.rotationDegrees(yaw));
         if (!block) {
            pose.mulPose(Axis.XP.rotationDegrees(90.0F));
         }
      } else {
         float age = ageInTicks * this.spin.floatValue() / 100.0F;
         pose.mulPose(Axis.YP.rotationDegrees(yaw + age * 9.0F));
         pose.mulPose(Axis.XP.rotationDegrees(age * 14.0F));
      }
   }

   public interface State {
      void minee$physics(boolean var1, int var2, boolean var3);

      boolean minee$onGround();

      int minee$id();

      boolean minee$block();
   }
}
