package dev.minee.module.impl;

import dev.minee.module.Category;
import dev.minee.module.Module;


public final class KeysModule extends Module {
   public KeysModule() {
      super("keys", Category.INTERFACE, true);
   }

   @Override
   public int icon() {
      return 57988;
   }

   @Override
   public boolean isAlwaysOn() {
      return true;
   }
}
